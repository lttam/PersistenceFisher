% set path for figtree
% precompiled for MAC 64-bit and Linux 64-bit

% For other cases, please read the readme of figtree
% For more up-to-date information on figtree library, please go to the 
% FIGTree homepage: http://www.umiacs.umd.edu/~morariu/figtree/ 
% or the SourceForge download page: http://sourceforge.net/projects/figtree

cd figtree-0.9.3/
cd matlab/
addpath(pwd)
cd ..
cd ..
